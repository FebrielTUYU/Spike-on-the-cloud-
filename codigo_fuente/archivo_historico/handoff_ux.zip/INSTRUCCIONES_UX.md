# Instrucciones para el diseñador UX

## Qué es esto
`dashboard_template.html` es el dashboard completo del Monitor de noticias, ya con datos reales
de una corrida (los mismos datos también están en `data.json`, por si querés inspeccionarlos aparte
o probar el HTML con otro set — ver más abajo). `logo.png` es el logo que usa la página.

## Cómo trabajar
Abrí `dashboard_template.html` directamente en tu navegador (doble clic, o arrastrarlo a una
pestaña) — no hace falta ningún servidor ni instalar nada. Todo el HTML, CSS y JavaScript están en
ese único archivo.

Tenés **libertad total** para cambiar estilos (CSS), estructura visual y comportamiento del
JavaScript: colores, tipografía, layout, animaciones, orden de las secciones, cómo se ven las
tarjetas, gráficos, etc.

## Lo que NO podés tocar
- **Los `id` de los elementos HTML** (ej. `id="secNoticias"`, `id="estadoIaNube"`, `id="chatWidget"`,
  etc.). El JavaScript los usa para encontrar dónde inyectar contenido — si cambiás un `id`, esa
  parte del dashboard deja de funcionar.
- **Las variables/funciones del script que leen los datos** (todo lo que empieza con `DATA.` en el
  JavaScript, y el bloque `<script id="payload" type="application/json">...</script>` que tiene los
  datos ya cargados adentro). Ese bloque es el "contenido" real del programa — es la única parte que
  no es diseño, es la información que el sistema recolectó.

Si necesitás agregar un `id` nuevo para algo tuyo (un contenedor, un botón nuevo), no hay problema.
El límite es no renombrar ni borrar los que ya existen.

## Por qué el archivo es tan pesado
`dashboard_template.html` pesa varios MB porque tiene los datos de una corrida real (~1500
historias) incrustados adentro del propio HTML, para que lo puedas abrir directo sin necesitar un
servidor corriendo. Es normal, no es un error.

## Cualquier duda
Preguntale a Fernando antes de asumir algo sobre por qué una parte del dashboard se ve o se
comporta de una manera puntual — varias decisiones de diseño actuales (qué se muestra "recientes"
vs. "anteriores", los toggles de ámbito Ecuador/Guayaquil/Mundo, el chat flotante, etc.) responden a
pedidos concretos y bugs reales ya resueltos, no son arbitrarias.
